[http://jmblog.mit-license.org/](http://jmblog.mit-license.org/)
